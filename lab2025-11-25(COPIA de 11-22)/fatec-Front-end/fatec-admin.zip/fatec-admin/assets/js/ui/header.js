
async function renderHeader() {
  const container = document.getElementById('site-header');
  const res = await fetch('./components/header.html');
  container.innerHTML = await res.text();

  const isAuth = Session.isAuthenticated();
  document.querySelectorAll('[data-route]').forEach(el => {
    el.style.display = isAuth ? 'block' : 'none';
  });

  const userArea = document.getElementById('user-area');
  if (!isAuth) {
    userArea.innerHTML = `
      <button class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">
        Login
      </button>
    `;
  } else {
    const u = Session.getUser();
    const nomeUnidade = u?.nomeUnidade ? ` • ${u.nomeUnidade}` : '';
    userArea.innerHTML = `
      <span class="text-white me-3">${u.nomeFuncionario} (${u.numeroMatricula})${nomeUnidade}</span>
      <button class="btn btn-outline-light" id="logout-btn">Sair</button>
    `;
    document.getElementById('logout-btn').addEventListener('click', () => {
      Session.clear();
      App.navigatePublic();
      Toast.show('Sessão encerrada.', 'success');
    });
  }
}

window.Header = { render: renderHeader };
