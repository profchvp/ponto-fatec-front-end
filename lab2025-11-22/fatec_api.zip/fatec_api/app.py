# app.py
from flask import Flask, request, jsonify
import sqlite3
import datetime as dt
from contextlib import contextmanager
from werkzeug.security import generate_password_hash, check_password_hash

APP_DB = "db.sqlite3"

app = Flask(__name__)

@contextmanager
def get_conn():
    conn = sqlite3.connect(APP_DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def now_iso():
    return dt.datetime.now().isoformat(timespec="seconds")

def create_tables():
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS unidade (
                codigoUnidade INTEGER PRIMARY KEY,
                nomeFatecUnidade TEXT NOT NULL,
                fatecDenominacaoOficial TEXT,
                nomeDiretor TEXT,
                dataInclusao TEXT NOT NULL
            );
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS usuario (
                emailFatec TEXT PRIMARY KEY,
                numeroMatricula TEXT,
                codigoUnidade INTEGER NOT NULL,
                nomeFuncionario TEXT NOT NULL,
                senhaLogin TEXT NOT NULL,
                indicadorAtivo INTEGER NOT NULL DEFAULT 1,
                dataInclusao TEXT NOT NULL,
                FOREIGN KEY (codigoUnidade)
                    REFERENCES unidade(codigoUnidade)
                    ON DELETE RESTRICT
                    ON UPDATE CASCADE
            );
            """
        )

create_tables()

@app.get('/health')
def health():
    return jsonify(status='ok', when=now_iso())

@app.post('/unidades')
def criar_unidade():
    try:
        data = request.get_json(force=True)
    except Exception:
        return jsonify(erro='JSON inválido'), 400

    required = ["codigoUnidade", "nomeUnidadeFatec", "denominacaoOficial", "nomeDiretor"]
    missing = [k for k in required if k not in data]
    if missing:
        return jsonify(erro=f"Campos obrigatórios ausentes: {', '.join(missing)}"), 400

    with get_conn() as conn:
        cur = conn.execute("SELECT 1 FROM unidade WHERE codigoUnidade = ?", (data['codigoUnidade'],))
        if cur.fetchone():
            return jsonify(erro='codigoUnidade já existe'), 409
        conn.execute(
            """
            INSERT INTO unidade (codigoUnidade, nomeFatecUnidade, fatecDenominacaoOficial, nomeDiretor, dataInclusao)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                data['codigoUnidade'],
                data['nomeUnidadeFatec'],
                data['denominacaoOficial'],
                data['nomeDiretor'],
                now_iso(),
            ),
        )
    return jsonify(status='OK', mensagem='Unidade cadastrada com sucesso'), 201

@app.delete('/unidades/<int:codigoUnidade>')
def excluir_unidade(codigoUnidade: int):
    try:
        with get_conn() as conn:
            cur = conn.execute("DELETE FROM unidade WHERE codigoUnidade = ?", (codigoUnidade,))
            if cur.rowcount == 0:
                return jsonify(erro='Unidade não encontrada'), 404
    except sqlite3.IntegrityError:
        return jsonify(erro='Exclusão negada: existem usuários vinculados a esta unidade'), 409
    return jsonify(status='OK', mensagem='Unidade excluída com sucesso'), 200

@app.post('/usuarios')
def criar_usuario():
    try:
        data = request.get_json(force=True)
    except Exception:
        return jsonify(erro='JSON inválido'), 400

    required = ["emailFatec", "codigoUnidade", "nomeFuncionario"]
    missing = [k for k in required if k not in data]
    if missing:
        return jsonify(erro=f"Campos obrigatórios ausentes: {', '.join(missing)}"), 400

    email = (data.get('emailFatec') or '').strip().lower()
    senha_clara = data.get('senhaLogin') or data.get('senha')
    if not senha_clara:
        return jsonify(erro="Campo 'senhaLogin' (ou 'senha') é obrigatório"), 400
    if len(senha_clara) < 6:
        return jsonify(erro='Senha muito curta (mínimo 6 caracteres)'), 400

    senha_hash = generate_password_hash(senha_clara, method='pbkdf2:sha256', salt_length=16)

    with get_conn() as conn:
        cur = conn.execute("SELECT 1 FROM unidade WHERE codigoUnidade = ?", (data['codigoUnidade'],))
        if not cur.fetchone():
            return jsonify(erro='codigoUnidade inexistente (FK inválida)'), 422

        cur = conn.execute("SELECT 1 FROM usuario WHERE emailFatec = ?", (email,))
        if cur.fetchone():
            return jsonify(erro='emailFatec já cadastrado'), 409

        conn.execute(
            """
            INSERT INTO usuario (emailFatec, numeroMatricula, codigoUnidade, nomeFuncionario, senhaLogin, indicadorAtivo, dataInclusao)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                email,
                data.get('numeroMatricula'),
                data['codigoUnidade'],
                data['nomeFuncionario'],
                senha_hash,
                1,
                now_iso(),
            ),
        )
    return jsonify(status='OK', mensagem='Usuario cadastrado com sucesso'), 201

@app.post('/auth/login')
def login():
    try:
        data = request.get_json(force=True)
    except Exception:
        return jsonify(erro='JSON inválido'), 400

    email = (data.get('email') or '').strip().lower()
    senha = data.get('senha')
    if not email or not senha:
        return jsonify(erro="Campos 'email' e 'senha' são obrigatórios"), 400

    with get_conn() as conn:
        cur = conn.execute(
            """
            SELECT emailFatec, numeroMatricula, codigoUnidade, nomeFuncionario, senhaLogin, indicadorAtivo
            FROM usuario WHERE emailFatec = ?
            """,
            (email,),
        )
        row = cur.fetchone()
        if not row:
            return jsonify(erro='Usuário não encontrado'), 404
        if not bool(row['indicadorAtivo']):
            return jsonify(erro='Usuário inativo'), 403
        if not check_password_hash(row['senhaLogin'], senha):
            return jsonify(erro='Senha inválida'), 401
        return jsonify({
            'nomeFuncionario': row['nomeFuncionario'],
            'numeroMatricula': row['numeroMatricula'],
            'codigoUnidade': row['codigoUnidade'],
            'emailFatec': row['emailFatec'],
        }), 200

@app.delete('/usuarios/<path:emailFatec>')
def excluir_usuario(emailFatec: str):
    email = (emailFatec or '').strip().lower()
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM usuario WHERE emailFatec = ?", (email,))
        if cur.rowcount == 0:
            return jsonify(erro='Usuário não encontrado'), 404
    return jsonify(status='OK', mensagem='Usuário excluído com sucesso'), 200

@app.post('/unidades/import-excel')
def importar_unidades_excel():
    if 'file' not in request.files:
        return jsonify(erro="Envie o arquivo em multipart/form-data no campo 'file'"), 400
    excel_file = request.files['file']
    try:
        import pandas as pd
    except Exception:
        return jsonify(erro="Dependências ausentes para Excel. Instale 'pandas' e 'openpyxl'."), 501
    try:
        df = pd.read_excel(excel_file)
    except Exception as e:
        return jsonify(erro=f'Falha ao ler Excel: {e}'), 400
    expected_cols = {"codigoUnidade", "nomeUnidadeFatec", "denominacaoOficial", "nomeDiretor"}
    if not expected_cols.issubset(set(df.columns)):
        return jsonify(erro=f"Colunas esperadas: {sorted(expected_cols)}. Colunas encontradas: {sorted(df.columns.tolist())}"), 400
    inseridos, ignorados = 0, 0
    with get_conn() as conn:
        for _, row in df.iterrows():
            codigo = int(row['codigoUnidade'])
            nome = str(row['nomeUnidadeFatec'])
            denom = None if pd.isna(row['denominacaoOficial']) else str(row['denominacaoOficial'])
            diretor = None if pd.isna(row['nomeDiretor']) else str(row['nomeDiretor'])
            cur = conn.execute("SELECT 1 FROM unidade WHERE codigoUnidade = ?", (codigo,))
            if cur.fetchone():
                ignorados += 1
                continue
            conn.execute(
                """
                INSERT INTO unidade (codigoUnidade, nomeFatecUnidade, fatecDenominacaoOficial, nomeDiretor, dataInclusao)
                VALUES (?, ?, ?, ?, ?)
                """,
                (codigo, nome, denom, diretor, now_iso()),
            )
            inseridos += 1
    return jsonify(status='OK', inseridos=inseridos, ignorados=ignorados), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
